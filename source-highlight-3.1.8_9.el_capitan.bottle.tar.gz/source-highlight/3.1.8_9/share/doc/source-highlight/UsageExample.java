/* 
   this is an example of code to be included
   in the javadoc documentation of SimpleClass
*/
import simpleclass.*;

// code snippet
SimpleClass s = new SimpleClass(150);
if (s == null && true) {
    throw new SimpleClassException("failed to create");
}
System.out.println("this is a simple class" + s);
