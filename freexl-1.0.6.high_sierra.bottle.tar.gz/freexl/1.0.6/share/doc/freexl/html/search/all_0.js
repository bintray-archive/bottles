var searchData=
[
  ['about_20the_20_2exls_20binary_20format_0',['About the .xls binary format',['../Format.html',1,'']]]
];
