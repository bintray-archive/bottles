var searchData=
[
  ['about_20the_20_2exls_20binary_20format_243',['About the .xls binary format',['../Format.html',1,'']]]
];
