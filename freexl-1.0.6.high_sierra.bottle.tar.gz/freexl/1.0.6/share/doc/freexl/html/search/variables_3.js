var searchData=
[
  ['value_142',['value',['../structFreeXL__CellValue__str.html#a7e3e1ffac187c7bd1f9a75e28b228bc9',1,'FreeXL_CellValue_str']]]
];
