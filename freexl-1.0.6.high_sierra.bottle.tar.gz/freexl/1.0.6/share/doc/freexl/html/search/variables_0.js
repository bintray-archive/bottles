var searchData=
[
  ['double_5fvalue_138',['double_value',['../structFreeXL__CellValue__str.html#ad125ce4ac1a2dde3bdcfa2750dd0815d',1,'FreeXL_CellValue_str']]]
];
