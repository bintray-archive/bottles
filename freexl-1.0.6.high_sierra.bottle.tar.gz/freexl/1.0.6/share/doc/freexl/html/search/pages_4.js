var searchData=
[
  ['the_20background_20story_20for_20freexl_247',['The background story for FreeXL',['../Origins.html',1,'']]]
];
