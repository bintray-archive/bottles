var searchData=
[
  ['freexl_5fcellvalue_5fstr_124',['FreeXL_CellValue_str',['../structFreeXL__CellValue__str.html',1,'']]]
];
