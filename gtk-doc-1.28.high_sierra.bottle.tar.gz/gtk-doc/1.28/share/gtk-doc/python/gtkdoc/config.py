version = "1.28"

# tools
dblatex = ''
fop = ''
highlight = '@@HOMEBREW_PREFIX@@/opt/source-highlight/bin/source-highlight'
highlight_options = '-t4 -s$SRC_LANG -cstyle.css --no-doc -i'
pkg_config = '@@HOMEBREW_PREFIX@@/opt/pkg-config/bin/pkg-config'
xsltproc = '/usr/bin/xsltproc'

# configured directories
prefix = '@@HOMEBREW_PREFIX@@/Cellar/gtk-doc/1.28'
datarootdir = "${prefix}/share".replace('${prefix}', prefix)
datadir = "${datarootdir}".replace('${datarootdir}', datarootdir)

exeext = ''
