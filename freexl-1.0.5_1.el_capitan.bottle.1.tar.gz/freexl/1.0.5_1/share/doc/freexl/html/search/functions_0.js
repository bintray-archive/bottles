var searchData=
[
  ['freexl_5fclose',['freexl_close',['../freexl_8h.html#a6122b2adf513c42a8ad5aa0e083a82bb',1,'freexl.h']]],
  ['freexl_5fget_5factive_5fworksheet',['freexl_get_active_worksheet',['../freexl_8h.html#ae6683eb98a9d01c745db397878d9933a',1,'freexl.h']]],
  ['freexl_5fget_5fcell_5fvalue',['freexl_get_cell_value',['../freexl_8h.html#aef8dc850a668e82b9aa2efde78cc427a',1,'freexl.h']]],
  ['freexl_5fget_5ffat_5fentry',['freexl_get_FAT_entry',['../freexl_8h.html#a9b68b6e59ee6ca4d3303f812dbefe679',1,'freexl.h']]],
  ['freexl_5fget_5finfo',['freexl_get_info',['../freexl_8h.html#ad6dbe072c7a4632853d90f4509bf3aee',1,'freexl.h']]],
  ['freexl_5fget_5fsst_5fstring',['freexl_get_SST_string',['../freexl_8h.html#af63ae08d341f25957601b7adc4fbeb33',1,'freexl.h']]],
  ['freexl_5fget_5fworksheet_5fname',['freexl_get_worksheet_name',['../freexl_8h.html#abba0c9d47eaba2ca2b8a093b03638219',1,'freexl.h']]],
  ['freexl_5fopen',['freexl_open',['../freexl_8h.html#acbd27ba5bc7b21d4ae32c0542d51f1e4',1,'freexl.h']]],
  ['freexl_5fopen_5finfo',['freexl_open_info',['../freexl_8h.html#abc44950b4d49580fa632d8c591612530',1,'freexl.h']]],
  ['freexl_5fselect_5factive_5fworksheet',['freexl_select_active_worksheet',['../freexl_8h.html#a248e690e125ee15eddacb25aa72b07a3',1,'freexl.h']]],
  ['freexl_5fversion',['freexl_version',['../freexl_8h.html#a52ed19917326cad3cb23ba1a66438276',1,'freexl.h']]],
  ['freexl_5fworksheet_5fdimensions',['freexl_worksheet_dimensions',['../freexl_8h.html#ace1d7e39a8874a9300821c22e5bb9643',1,'freexl.h']]]
];
