var searchData=
[
  ['text_5fvalue',['text_value',['../structFreeXL__CellValue__str.html#a2f0f6b8e3bb3503487107037a769e56e',1,'FreeXL_CellValue_str']]],
  ['type',['type',['../structFreeXL__CellValue__str.html#af2b1f157e4dc4508b1c4e303429c01d5',1,'FreeXL_CellValue_str']]]
];
