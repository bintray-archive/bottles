var searchData=
[
  ['about_20the_20_2exls_20binary_20format',['About the .xls binary format',['../Format.html',1,'']]]
];
