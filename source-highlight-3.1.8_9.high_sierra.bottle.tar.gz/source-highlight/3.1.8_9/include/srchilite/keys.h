#ifndef KEYS_H
#define KEYS_H

namespace srchilite {

#define NORMAL "normal"

}

#endif
