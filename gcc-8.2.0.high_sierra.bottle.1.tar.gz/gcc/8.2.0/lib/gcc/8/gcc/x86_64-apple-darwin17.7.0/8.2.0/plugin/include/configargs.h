/* Generated automatically. */
static const char configuration_arguments[] = "../configure --build=x86_64-apple-darwin17.7.0 --prefix=@@HOMEBREW_CELLAR@@/gcc/8.2.0 --libdir=@@HOMEBREW_CELLAR@@/gcc/8.2.0/lib/gcc/8 --enable-languages=c,c++,objc,obj-c++,fortran --program-suffix=-8 --with-gmp=@@HOMEBREW_PREFIX@@/opt/gmp --with-mpfr=@@HOMEBREW_PREFIX@@/opt/mpfr --with-mpc=@@HOMEBREW_PREFIX@@/opt/libmpc --with-isl=@@HOMEBREW_PREFIX@@/opt/isl --with-system-zlib --enable-checking=release --with-pkgversion='Homebrew GCC 8.2.0' --with-bugurl=https://github.com/Homebrew/homebrew-core/issues --disable-nls";
static const char thread_model[] = "posix";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { "cpu", "core2" } };
